from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import pandas as pd
import time  # Import the time module

# Set up the ChromeDriver (download from https://sites.google.com/chromium.org/driver/)
driver = webdriver.Chrome()

# Create a list to store structured data
structured_data = []

# Construct the artist URL
artist_name = "Ayman-Alatar"  # Replace with the actual artist name
artist_url = f"https://www.musixmatch.com/artist/{artist_name}"

# Navigate to the artist's page
driver.get(artist_url)

# Function to click the "Load More" button
def click_load_more():
    try:
        load_more_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'div.load-more-pager a'))
        )
        load_more_button.click()
    except Exception as e:
        print(f"Error clicking 'Load More': {e}")

# Click "Load More" until it is not present (you may need to adjust the condition)
while True:
    click_load_more()
    # Wait for the page to load after clicking "Load More"
    driver.implicitly_wait(10)
    # Break the loop if there are no more "Load More" buttons
    if not driver.find_elements(By.CSS_SELECTOR, 'div.load-more-pager a'):
        break

# Get the page source after dynamic content is loaded
page_source = driver.page_source

# Parse the HTML content of the page using BeautifulSoup
soup = BeautifulSoup(page_source, 'html.parser')

# Find all the track links on the artist's page
track_links = soup.select('ul.tracks.list li.showCoverart a.title')

# Iterate over the track links and extract information
for link in track_links:
    track_name = link.find('span').text

    # Visit the track's URL
    driver.get("https://www.musixmatch.com" + link['href'])

    # Wait for the track page to load
    driver.implicitly_wait(10)

    # Get the page source after dynamic content is loaded
    track_page_source = driver.page_source

    # Parse the HTML content of the track page
    track_soup = BeautifulSoup(track_page_source, 'html.parser')

    # Extract all spans with the class 'lyrics__content__ok'
    lyrics_elements = track_soup.find_all('span', {'class': 'lyrics__content__ok'})

    # Concatenate the text content of all spans
    lyrics = '\n'.join([element.text.strip() for element in lyrics_elements])

    # Append the data to the list
    structured_data.append({
        'artist_name': artist_name,
        'track_name': track_name,
        'lyrics': lyrics
    })

    # Wait for 20 seconds before visiting the next link
    time.sleep(10)

# Create a DataFrame from the structured data
df = pd.DataFrame(structured_data)

# Save the DataFrame to a CSV file with the artist's name
csv_filename = f'./lyricsScrapping/{artist_name}_lyrics_data.csv'
df.to_csv(csv_filename, index=False)

# Close the browser
driver.quit()
