import csv
import requests
from bs4 import BeautifulSoup
from itertools import cycle
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import pandas as pd

# Loading proxies from CSV file
csv_proxies_path = 'lyricsScrapping/proxies.csv'
proxies = []

with open(csv_proxies_path, newline='') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        proxy = row['proxy'].strip()
        proxies.append(proxy)

# Create an infinite cyclic iterator for proxy rotation
proxy_pool = cycle(proxies)

# Loading the names from the CSV file
csv_file_path = 'artist_names.csv'



# Initialize an empty array to store the names
artist_names_from_csv = []

# Open the CSV file and read names from the 'ArtistName' column
with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        artist_names_from_csv.append(row['artist_name'])

# Set up the ChromeDriver (download from https://sites.google.com/chromium.org/driver/)
driver = webdriver.Chrome()

# Create a list to store structured data
structured_data = []

# Iterate over artist names
for artist_name in artist_names_from_csv:
    # Get the next proxy from the rotation
    proxy = next(proxy_pool)

    # Construct the artist URL
    artist_url = f"https://www.musixmatch.com/artist/{artist_name}"

    # Set up the proxy for the request
    proxies = {'http': f'http://{proxy}', 'https': f'http://{proxy}'}

    try:
        # Send a request with proxy
        response = requests.get(artist_url, proxies=proxies, timeout=10)
        response.raise_for_status()

        # Parse the HTML content of the page using BeautifulSoup
        soup = BeautifulSoup(response.content, 'html.parser')

        # Find all the track links on the artist's page
        track_links = soup.select('ul.tracks.list li.showCoverart a.title')

        # Iterate over the track links and extract information
        for link in track_links:
            track_name = link.find('span').text

            # Visit the track's URL
            driver.get("https://www.musixmatch.com" + link['href'])

            # Wait for the track page to load
            driver.implicitly_wait(10)

            # Get the page source after dynamic content is loaded
            track_page_source = driver.page_source

            # Parse the HTML content of the track page
            track_soup = BeautifulSoup(track_page_source, 'html.parser')

            # Extract all spans with the class 'lyrics__content__ok'
            lyrics_elements = track_soup.find_all('span', {'class': 'lyrics__content__ok'})

            # Concatenate the text content of all spans
            lyrics = '\n'.join([element.text.strip() for element in lyrics_elements])

            # Append the data to the list
            structured_data.append({
                'artist_name': artist_name,
                'track_name': track_name,
                'lyrics': lyrics
            })

    except requests.exceptions.RequestException as e:
        print(f"Error fetching {artist_url} with proxy {proxy}: {e}")

# Create a DataFrame from the structured data
df = pd.DataFrame(structured_data)

# Save the DataFrame to a CSV file
df.to_csv('./lyricsScrapping/lyrics_data.csv', index=False)

# Close the browser
driver.quit()
