from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from bs4 import BeautifulSoup
import time
import csv






# Replace this with the URL of the genre page
genre_url = "https://www.musixmatch.com/explore/genre/Arabic-North-African"

# Set up the ChromeDriver (download from https://sites.google.com/chromium.org/driver/)
driver = webdriver.Chrome()

# Navigate to the genre page
driver.get(genre_url)

# Wait for the page to load
driver.implicitly_wait(10)

# Function to click the "Load More" button
def click_load_more():
    load_more_button = driver.find_element(By.CLASS_NAME, 'page-load-more')
    ActionChains(driver).move_to_element(load_more_button).click().perform()

# Simulate clicking the "Load More" button five times
for _ in range(4):
    click_load_more()
    time.sleep(3)  # Add a delay to allow content to load (you may need to adjust this)

# Get the page source after dynamic content is loaded
page_source = driver.page_source

# Parse the HTML content of the page using BeautifulSoup
soup = BeautifulSoup(page_source, 'html.parser')

# Find all the artist names on the page
artist_links = soup.find_all('a', class_='artist')

# Extract artist names
artist_names = [link.text.strip() for link in artist_links]
unique_artist_names = list(set(artist_names))

with open('artist_names.csv', 'w', encoding='utf-8', newline='') as csvfile:
    fieldnames = ['artist_name']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    # Write header
    writer.writeheader()

    # Write artist names
    for name in unique_artist_names:
        # Replace spaces with dashes for names with two parts
        formatted_name = '-'.join(name.split())
        writer.writerow({'artist_name': formatted_name})
        
        
driver.quit()
